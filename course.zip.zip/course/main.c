/**
 * @file main.c
 * @author Karl Sader (saderk@mcmaster.ca)
 * @brief This file contains the main function that is run. It's primary objective is to create a type Course, add students to that course, and print certain information about that course using the functions created in course.c and student.c.
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

/**
 * @brief The main function created a class called MATH101 and gives it all its attributes including its name, code, and students.
 * @brief It inputs 20 random students into the course using the enroll_student and generate_randon_student functions. It then prints the course contents using the print_course function.
 * @brief It then prints the top student, the number of passing students, and it lists all of the passing students (using the passing and print_student functions).
 * 
 * @return int of type Int (Since the main function is not a void function, it simply returns 0 because the function requires an output.)
 */
int main()
{
  srand((unsigned) time(NULL));

  Course *MATH101 = calloc(1, sizeof(Course));
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

  //This for loop generates 20 random students and inserts them into the students list of the course.
  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  
  print_course(MATH101);

  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);

  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  //This for loop goes through the list of students that are passing and prints them using the print_student function.
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  
  return 0;
}