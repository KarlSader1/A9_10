/**
 * @file student.h
 * @author Karl Sader (saderk@mcmaster.ca)
 * @brief This file contains the typedef struct of Student, and defines a variety of functions using the type Student.
 * @version 0.1
 * @date 2022-04-11
 * 
 * @copyright Copyright (c) 2022
 */

/**
 * @brief Student type stores the fields first_name (array of characters), last_name (array of characters), id (array of characters), grades (double), num_grades (int).
 */
typedef struct _student 
{ 
  char first_name[50]; /**< the first name of the student*/
  char last_name[50]; /**< the last name of the student*/
  char id[11]; /**< the id of the student*/
  double *grades; /**< the students grade*/
  int num_grades; /**< the students number of grades*/
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
