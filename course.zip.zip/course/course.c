/**
 * @file course.c
 * @author Karl Sader (saderk@mcmaster.ca)
 * @brief This file contains a variety of functions to be used on Course types.
 * @version 0.1
 * @date 2022-04-11
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include "course.h"
#include <stdlib.h>
#include <stdio.h>

/**
 * @brief The enroll_student takes in a type Course and a type Student and adds that student to the course.
 * @brief It increments the total_students attribute by 1. It then allocates or reallocates memory depending on if the student being added is the only one in the course or not.
 * @brief It then adds the student to the students attribute.
 * 
 * @param course of type Course
 * @param student of type Student
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
}

/**
 * @brief The print_course function takes in a type Course and prints all the necessary attributes in the course.
 * @brief It prints the course name, the course code, the number of total_students, and using the print_student function, it prints all of the students in the course.
 * 
 * @param course of type Course
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  //This for loop goes through the list of students and prints all of the students using the print_student function.
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/**
 * @brief The top_student function takes in a type Course and returns the student with the highest grade in that course. It nobody is in the course, NULL is returned.
 * 
 * @param course of type Course
 * @return Student* of type Student
 */
Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
  
  //This for loop goes through the list of students in the course and keeps track of which student has the highest grade until the loop is complete.
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

/**
 * @brief The passing function takes in a type Course and a type Int and calculates the number of students who are passing the course, while also returning a list of students who are passing.
 * 
 * @param course of type Course
 * @param total_passing of type Int
 * @return Student* of type Student
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  //This for loop goes through the students in the course and increments the counter variable by 1 if the student is passing.
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  passing = calloc(count, sizeof(Student));

  int j = 0;

  //This for loop goes through the students in the course and adds the students who are passing to a list.
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}